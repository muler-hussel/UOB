package edu.uob;

public class Inventory extends Location{
    public Inventory(String name, String description) {
        super(name, description);
    }
}
